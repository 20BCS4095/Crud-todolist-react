import "./App.css";
import { useState } from "react";
function App() {
  const [todoList, setTodoList] = useState([]);
  const [printtodolist,setprinttodolist]=useState([]);
  const [newTask, setNewTask] = useState("");
  const [noofitem, setNoOfItem] = useState("");
  const [costofitem, setCostofItems] = useState("");
  const [bil,setbil]=useState("");
  let handleChange = (event) => {
    setNewTask(event.target.value);
  };
  const handleChange1 = (event) => {
    setNoOfItem(event.target.value);
  };
  const handleChange2 = (event) => {
    setCostofItems(event.target.value);
  };
  const addTask = () => {
    document.getElementById("name").value = "";
    document.getElementById("numbe").value = "";
    document.getElementById("cost").value = "";
    const n = parseInt(noofitem) * parseInt(costofitem);
    const task = {
      id: todoList.length === 0 ? 1 : todoList[todoList.length - 1].id + 1,
      taskName: newTask,
      taskNumber: noofitem,
      cost: costofitem,
      total: n,
    };
    const newtodoList = [...todoList, task];
    setTodoList(newtodoList);
   
  };
  const deleteTask = (id) => {
    const newtodoList1 = todoList.filter((name) => {
      if (name.id === id) return false;
      else return true;
    });
    setTodoList(newtodoList1);
  };
  const edit = (id) => {
    const newto = todoList.filter((name) => {
      if (name.id === id) {
        document.getElementById("name").value = name.taskName;
        document.getElementById("numbe").value = name.taskNumber;
        document.getElementById("cost").value = name.cost;
        return false;
      } else return true;
    });
    setTodoList(newto);
  };
  const printbill=()=>{
    let c=0;
     todoList.forEach(element => {
      c+=parseInt(element.total);
     });
     setbil(c);
    setprinttodolist(todoList);
  };
  return (
    <div className="App">
      <h1>Shopping Bill List</h1>
      <div className="addTask">
        <input id="name" onChange={handleChange} placeholder="Name of items" />
        <input
          id="numbe"
          onChange={handleChange1}
          placeholder="Number of items"
        />
        <input id="cost" onChange={handleChange2} placeholder="Cost of items" />
        <button onClick={addTask}>Bill</button>
      </div>
      <br />
      <div className="list">
        <table>
          <tr>
            <th>Product Name</th>
            <th>No Of Items</th>
            <th>Cost of one item</th>
            <th>Total Cost</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </table>
        {todoList.map((task) => {
          return (
            <div>
              <table>
                {" "}
                <tr>
                  <td>{task.taskName}</td>
                  <td>{task.taskNumber}</td>
                  <td>{task.cost}</td>
                  <td>{task.total}</td>
                  <td>
                    <button onClick={() => edit(task.id)}>Edit</button>
                  </td>
                  <td>
                    <button onClick={() => deleteTask(task.id)}>Delete</button>
                  </td>
                </tr>
              </table>
            </div>
          );
        })}
        <button className="bill" onClick={()=> printbill()}>Total Bill</button>
        <h1>See Your bill here</h1>
        <table><tr>
            <th>Product Name</th>
            <th>No Of Items</th>
            <th>Cost of one item</th>
            <th>Total Cost</th>
          </tr></table>
        {printtodolist.map((task)=>{
          return(
            <div><table><tr>
              <td>{task.taskName}</td>
              <td>{task.taskNumber}</td>
              <td>{task.cost}</td>
              <td>{task.total}</td></tr></table></div>
          );
        })}
        <h3>Total Amount : {bil}</h3>
      </div>
    </div>
  );
}

export default App;
